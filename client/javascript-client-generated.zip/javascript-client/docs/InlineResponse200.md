# EducationManageApi.InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userName** | **String** |  | [optional] 
**token** | **String** |  | [optional] 



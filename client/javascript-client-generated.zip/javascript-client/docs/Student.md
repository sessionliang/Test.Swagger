# EducationManageApi.Student

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**userName** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**password** | **String** |  | [optional] 
**phone** | **String** |  | [optional] 
**userStatus** | **Number** | User Status | [optional] 



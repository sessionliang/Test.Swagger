'use strict';

var url = require('url');


var Students = require('./StudentsService');


module.exports.studentsLoginPOST = function studentsLoginPOST (req, res, next) {
  Students.studentsLoginPOST(req.swagger.params, res, next);
};

module.exports.studentsRegistePOST = function studentsRegistePOST (req, res, next) {
  Students.studentsRegistePOST(req.swagger.params, res, next);
};

module.exports.studentsStudentIdDELETE = function studentsStudentIdDELETE (req, res, next) {
  Students.studentsStudentIdDELETE(req.swagger.params, res, next);
};

module.exports.studentsStudentIdGET = function studentsStudentIdGET (req, res, next) {
  Students.studentsStudentIdGET(req.swagger.params, res, next);
};

module.exports.studentsStudentIdPUT = function studentsStudentIdPUT (req, res, next) {
  Students.studentsStudentIdPUT(req.swagger.params, res, next);
};
